﻿namespace CONSULTORIO_CON_SQLITE
{
    partial class MENU
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.aRCHIVOToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pACIENTESToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bUSCARPACIENTESToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lISTASDEPACIENTESToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bUSCARPACIENTESToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.iNFORMEPACIENTESToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cITASAGENDASToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cONSULTASToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.uRGENCIASToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cONSULTAINTERNAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cONSULTAEXTERNAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eXPEDIENTEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lABORATORIOToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.button1 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.rESETAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.Yellow;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aRCHIVOToolStripMenuItem,
            this.pACIENTESToolStripMenuItem,
            this.cONSULTASToolStripMenuItem,
            this.uRGENCIASToolStripMenuItem,
            this.lABORATORIOToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1245, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // aRCHIVOToolStripMenuItem
            // 
            this.aRCHIVOToolStripMenuItem.Name = "aRCHIVOToolStripMenuItem";
            this.aRCHIVOToolStripMenuItem.Size = new System.Drawing.Size(70, 20);
            this.aRCHIVOToolStripMenuItem.Text = "ARCHIVO";
            // 
            // pACIENTESToolStripMenuItem
            // 
            this.pACIENTESToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bUSCARPACIENTESToolStripMenuItem,
            this.bUSCARPACIENTESToolStripMenuItem1,
            this.cITASAGENDASToolStripMenuItem});
            this.pACIENTESToolStripMenuItem.Name = "pACIENTESToolStripMenuItem";
            this.pACIENTESToolStripMenuItem.Size = new System.Drawing.Size(77, 20);
            this.pACIENTESToolStripMenuItem.Text = "PACIENTES";
            // 
            // bUSCARPACIENTESToolStripMenuItem
            // 
            this.bUSCARPACIENTESToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lISTASDEPACIENTESToolStripMenuItem});
            this.bUSCARPACIENTESToolStripMenuItem.Name = "bUSCARPACIENTESToolStripMenuItem";
            this.bUSCARPACIENTESToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.bUSCARPACIENTESToolStripMenuItem.Text = "ALTAS PACIENTES";
            this.bUSCARPACIENTESToolStripMenuItem.Click += new System.EventHandler(this.bUSCARPACIENTESToolStripMenuItem_Click);
            // 
            // lISTASDEPACIENTESToolStripMenuItem
            // 
            this.lISTASDEPACIENTESToolStripMenuItem.Name = "lISTASDEPACIENTESToolStripMenuItem";
            this.lISTASDEPACIENTESToolStripMenuItem.Size = new System.Drawing.Size(186, 22);
            this.lISTASDEPACIENTESToolStripMenuItem.Text = "LISTAS DE PACIENTES";
            this.lISTASDEPACIENTESToolStripMenuItem.Click += new System.EventHandler(this.lISTASDEPACIENTESToolStripMenuItem_Click);
            // 
            // bUSCARPACIENTESToolStripMenuItem1
            // 
            this.bUSCARPACIENTESToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.iNFORMEPACIENTESToolStripMenuItem,
            this.rESETAToolStripMenuItem});
            this.bUSCARPACIENTESToolStripMenuItem1.Name = "bUSCARPACIENTESToolStripMenuItem1";
            this.bUSCARPACIENTESToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.bUSCARPACIENTESToolStripMenuItem1.Text = "CONSULTAS";
            this.bUSCARPACIENTESToolStripMenuItem1.Click += new System.EventHandler(this.bUSCARPACIENTESToolStripMenuItem1_Click);
            // 
            // iNFORMEPACIENTESToolStripMenuItem
            // 
            this.iNFORMEPACIENTESToolStripMenuItem.Name = "iNFORMEPACIENTESToolStripMenuItem";
            this.iNFORMEPACIENTESToolStripMenuItem.Size = new System.Drawing.Size(183, 22);
            this.iNFORMEPACIENTESToolStripMenuItem.Text = "INFORMEPACIENTES";
            this.iNFORMEPACIENTESToolStripMenuItem.Click += new System.EventHandler(this.iNFORMEPACIENTESToolStripMenuItem_Click);
            // 
            // cITASAGENDASToolStripMenuItem
            // 
            this.cITASAGENDASToolStripMenuItem.Name = "cITASAGENDASToolStripMenuItem";
            this.cITASAGENDASToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.cITASAGENDASToolStripMenuItem.Text = "CITAS AGENDA";
            this.cITASAGENDASToolStripMenuItem.Click += new System.EventHandler(this.cITASAGENDASToolStripMenuItem_Click);
            // 
            // cONSULTASToolStripMenuItem
            // 
            this.cONSULTASToolStripMenuItem.Name = "cONSULTASToolStripMenuItem";
            this.cONSULTASToolStripMenuItem.Size = new System.Drawing.Size(77, 20);
            this.cONSULTASToolStripMenuItem.Text = "FARMACIA";
            this.cONSULTASToolStripMenuItem.Click += new System.EventHandler(this.cONSULTASToolStripMenuItem_Click);
            // 
            // uRGENCIASToolStripMenuItem
            // 
            this.uRGENCIASToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cONSULTAINTERNAToolStripMenuItem,
            this.cONSULTAEXTERNAToolStripMenuItem,
            this.eXPEDIENTEToolStripMenuItem});
            this.uRGENCIASToolStripMenuItem.Name = "uRGENCIASToolStripMenuItem";
            this.uRGENCIASToolStripMenuItem.Size = new System.Drawing.Size(82, 20);
            this.uRGENCIASToolStripMenuItem.Text = "URGENCIAS";
            // 
            // cONSULTAINTERNAToolStripMenuItem
            // 
            this.cONSULTAINTERNAToolStripMenuItem.Name = "cONSULTAINTERNAToolStripMenuItem";
            this.cONSULTAINTERNAToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.cONSULTAINTERNAToolStripMenuItem.Text = "CONSULTA INTERNA";
            this.cONSULTAINTERNAToolStripMenuItem.Click += new System.EventHandler(this.cONSULTAINTERNAToolStripMenuItem_Click);
            // 
            // cONSULTAEXTERNAToolStripMenuItem
            // 
            this.cONSULTAEXTERNAToolStripMenuItem.Name = "cONSULTAEXTERNAToolStripMenuItem";
            this.cONSULTAEXTERNAToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.cONSULTAEXTERNAToolStripMenuItem.Text = "CONSULTA EXTERNA";
            // 
            // eXPEDIENTEToolStripMenuItem
            // 
            this.eXPEDIENTEToolStripMenuItem.Name = "eXPEDIENTEToolStripMenuItem";
            this.eXPEDIENTEToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.eXPEDIENTEToolStripMenuItem.Text = "EXPEDIENTE";
            // 
            // lABORATORIOToolStripMenuItem
            // 
            this.lABORATORIOToolStripMenuItem.Name = "lABORATORIOToolStripMenuItem";
            this.lABORATORIOToolStripMenuItem.Size = new System.Drawing.Size(96, 20);
            this.lABORATORIOToolStripMenuItem.Text = "LABORATORIO";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Yellow;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Yellow;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(1223, 0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(21, 24);
            this.button1.TabIndex = 1;
            this.button1.Text = "X";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Image = global::CONSULTORIO_CON_SQLITE.Properties.Resources.images_jpeg_3;
            this.pictureBox1.Location = new System.Drawing.Point(0, 23);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1245, 886);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // rESETAToolStripMenuItem
            // 
            this.rESETAToolStripMenuItem.Name = "rESETAToolStripMenuItem";
            this.rESETAToolStripMenuItem.Size = new System.Drawing.Size(183, 22);
            this.rESETAToolStripMenuItem.Text = "RESETA";
            this.rESETAToolStripMenuItem.Click += new System.EventHandler(this.RESETAToolStripMenuItem_Click);
            // 
            // MENU
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Aquamarine;
            this.ClientSize = new System.Drawing.Size(1245, 906);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MENU";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MENU";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem aRCHIVOToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pACIENTESToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bUSCARPACIENTESToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cONSULTASToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bUSCARPACIENTESToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem cITASAGENDASToolStripMenuItem;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ToolStripMenuItem iNFORMEPACIENTESToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ToolStripMenuItem lISTASDEPACIENTESToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem uRGENCIASToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cONSULTAINTERNAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cONSULTAEXTERNAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eXPEDIENTEToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lABORATORIOToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rESETAToolStripMenuItem;
    }
}