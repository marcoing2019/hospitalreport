﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CONSULTORIO_CON_SQLITE
{
      public static class CONEXION
    {
        public const string CADENA = "Data Source=USUARIOS.db;Version=3;";
    }
}
